package br.com.gestaofinanceira.service_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
