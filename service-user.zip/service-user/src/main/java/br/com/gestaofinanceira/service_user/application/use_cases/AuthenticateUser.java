package br.com.gestaofinanceira.service_user.application.use_cases;

public class AuthenticateUser {
    //implementar depois
}
