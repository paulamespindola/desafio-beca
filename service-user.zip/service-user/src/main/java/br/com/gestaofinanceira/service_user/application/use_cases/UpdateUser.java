package br.com.gestaofinanceira.service_user.application.use_cases;

import br.com.gestaofinanceira.service_user.application.gateway.UserRepository;
import br.com.gestaofinanceira.service_user.domain.User;

public class UpdateUser {
    private final UserRepository repository;

    public UpdateUser(UserRepository repository) {
        this.repository = repository;
    }

    public User updateUser(String cpf, User user) {
        User userUpdate = repository.updateUser(cpf, user);
        userUpdate.updateAt();
        return userUpdate;
    }

}
