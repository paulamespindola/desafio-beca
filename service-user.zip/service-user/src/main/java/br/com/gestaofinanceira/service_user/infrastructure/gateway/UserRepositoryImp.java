package br.com.gestaofinanceira.service_user.infrastructure.gateway;

import br.com.gestaofinanceira.service_user.application.gateway.UserRepository;
import br.com.gestaofinanceira.service_user.domain.User;
import br.com.gestaofinanceira.service_user.infrastructure.persistence.UserEntity;
import br.com.gestaofinanceira.service_user.infrastructure.persistence.UserRepositoryJpa;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class UserRepositoryImp implements UserRepository {

    @Autowired
    private UserRepositoryJpa repository;
    @Autowired
    private  UserEntityMapper mapper;

    @Override
    public User createUser(User user) {
        UserEntity userEntity = mapper.toEntity(user);
        repository.save(userEntity);
        return mapper.toDomain(userEntity);
    }

    @Override
    public User getUser(String cpf) {
        UserEntity userEntity = repository.findByCpf(cpf);
        return mapper.toDomain(userEntity);
    }

    @Override
    public List<User> ListUser() {
        List<UserEntity> userEntity = repository.findAllByStatusActive();
        return userEntity.stream()
                .map(u -> mapper.toDomain(u))
                .toList();
    }

    @Override
    public User updateUser(String cpf, User user) {
        return null;
    }

    @Override
    public void deleteUser(String cpf) {
        UserEntity entity = repository.findByCpf(cpf);
        User user = mapper.toDomain(entity);
        user.deleteUser();
        repository.save(mapper.toEntity(user));
    }
}
