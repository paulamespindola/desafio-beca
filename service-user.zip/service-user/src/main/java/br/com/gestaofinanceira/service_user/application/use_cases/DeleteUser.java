package br.com.gestaofinanceira.service_user.application.use_cases;

import br.com.gestaofinanceira.service_user.application.gateway.UserRepository;
import br.com.gestaofinanceira.service_user.domain.User;

public class DeleteUser {
    private final UserRepository repository;

    public DeleteUser(UserRepository repository) {
        this.repository = repository;
    }

    public void getUser(String cpf) {
        User user = repository.getUser(cpf);
        user.deleteUser();
    }

}
