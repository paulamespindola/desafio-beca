package br.com.gestaofinanceira.service_user.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class User {
    private final String cpf;
    private final String name;
    private final String email;
    private final String passwordHash;
    private final LocalDate birthDate;
    private final Role role;
    private Status status;
    private final LocalDateTime createdAt;
    private LocalDateTime updateAt;
    private LocalDateTime deletedAt;

    public User(String cpf, String name, String email, String passwordHash, LocalDate birthDate) {
        this.cpf = cpf;
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
        this.birthDate = birthDate;
        this.role = Role.USER;
        this.status = Status.ACTIVE;
        this.createdAt = LocalDateTime.now();
    }

    public User(String cpf, String name, String email, String passwordHash, LocalDate birthDate,
                Role role, Status status, LocalDateTime createdAt, LocalDateTime updateAt,
                LocalDateTime deletedAt) {
        this.cpf = cpf;
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
        this.birthDate = birthDate;
        this.role = role;
        this.status = status;
        this.createdAt = createdAt;
        this.updateAt = updateAt;
        this.deletedAt = deletedAt;
    }

    public void updateAt(){
        updateAt = LocalDateTime.now();
   }

   public void deleteUser(){
        status = Status.INACTIVE;
        deletedAt = LocalDateTime.now();
   }

    public String getCpf() {
        return cpf;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public Role getRole() {
        return role;
    }

    public Status getStatus() {
        return status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdateAt() {
        return updateAt;
    }

    public LocalDateTime getDeletedAt() {
        return deletedAt;
    }
}
