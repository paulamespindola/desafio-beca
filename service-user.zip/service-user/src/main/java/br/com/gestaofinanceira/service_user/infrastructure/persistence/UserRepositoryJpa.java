package br.com.gestaofinanceira.service_user.infrastructure.persistence;

import br.com.gestaofinanceira.service_user.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface UserRepositoryJpa extends JpaRepository<UserEntity, String> {

    UserEntity findByCpf(String cpf);

    List<UserEntity> findAllByStatusActive();
}
