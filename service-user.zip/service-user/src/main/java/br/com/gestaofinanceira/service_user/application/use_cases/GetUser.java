package br.com.gestaofinanceira.service_user.application.use_cases;

import br.com.gestaofinanceira.service_user.application.gateway.UserRepository;
import br.com.gestaofinanceira.service_user.domain.User;

public class GetUser {
    private final UserRepository repository;

    public GetUser(UserRepository repository) {
        this.repository = repository;
    }

    public User getUser(String cpf) {
        return repository.getUser(cpf);
    }

}
