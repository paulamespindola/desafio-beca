package br.com.gestaofinanceira.service_user.application.gateway;

import br.com.gestaofinanceira.service_user.domain.User;

import java.util.List;

public interface UserRepository {
    User createUser(User user);
    User getUser(String cpf);
    List<User> ListUser();
    User updateUser(String cpf, User user);
    void deleteUser(String cpf);
}
