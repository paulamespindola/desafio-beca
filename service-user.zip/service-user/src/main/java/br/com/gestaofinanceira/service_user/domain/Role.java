package br.com.gestaofinanceira.service_user.domain;

public enum Role {
    USER, ADMIN
}
