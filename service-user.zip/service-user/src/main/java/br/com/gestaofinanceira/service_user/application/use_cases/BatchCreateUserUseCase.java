package br.com.gestaofinanceira.service_user.application.use_cases;

import br.com.gestaofinanceira.service_user.application.gateway.UserRepository;
import br.com.gestaofinanceira.service_user.domain.User;

import java.util.List;

public class BatchCreateUserUseCase {
    private final UserRepository repository;

    public BatchCreateUserUseCase(UserRepository repository) {
        this.repository = repository;
    }

    public List<User> batchCreateUser(List<User> user) {
        return user.stream()
                        .map(repository::createUser)
                .toList();
    }
}
