package br.com.gestaofinanceira.service_user.infrastructure.controller;

import br.com.gestaofinanceira.service_user.application.use_cases.*;
import br.com.gestaofinanceira.service_user.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private BatchCreateUserUseCase batchCreateUserUseCase;
    @Autowired
    private CreateUserUseCase createUserUseCase;
    @Autowired
    private DeleteUser deleteUser;
    @Autowired
    private GetUser getUser;
    @Autowired
    private ListUsers listUsers;
    @Autowired
    private UpdateUser updateUser;


//    @PostMapping
//    public ResponseEntity<UserCreateResponseDto> createUser(UserCreateRequestDto user){
//
//    }

}
