package br.com.gestaofinanceira.service_user.application.use_cases;

import br.com.gestaofinanceira.service_user.application.gateway.UserRepository;
import br.com.gestaofinanceira.service_user.domain.User;

import java.util.List;

public class ListUsers {
    private final UserRepository repository;

    public ListUsers(UserRepository repository) {
        this.repository = repository;
    }

    public List<User> getUser(String cpf) {
        return repository.ListUser();
    }

}
