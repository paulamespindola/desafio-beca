package br.com.gestaofinanceira.service_user.domain;

public enum Status {
    ACTIVE, INACTIVE
}
